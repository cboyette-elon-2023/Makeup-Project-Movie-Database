package Displays;

import java.util.HashMap;
import java.util.Scanner;

public abstract class FollowUpQuestion {

	protected String input;
	
	// Asks the user a follow up question and catches any bad inputs
	protected void askFollowUp(Scanner userInput, HashMap<String,HashMap<String,String>> movies, String questionPrompt, String errorMessage) {
		System.out.println(questionPrompt);
		input = userInput.nextLine();
		try {
			testInput(input);
		}
		
		catch (IllegalArgumentException e) {
			System.out.println(errorMessage);
			askFollowUp(userInput, movies, questionPrompt, errorMessage);
		}
	}
	
	/* Method to ask the user a question
	 * If user gives an appropriate input, it will call a method to answer the question
	 * If not, it will ask the question again to the user and give a bad input message
	 */
	public abstract void askQuestion(Scanner userInput, HashMap<String,HashMap<String,String>> movies);
	
	// Method to test if user has given a valid input
	public abstract void testInput(String userChoice);
}
