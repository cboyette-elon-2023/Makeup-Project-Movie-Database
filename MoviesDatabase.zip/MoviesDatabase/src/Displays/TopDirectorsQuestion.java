package Displays;
import java.util.HashMap;
import java.util.Scanner;

import Question.TopDirectors;

public class TopDirectorsQuestion extends FollowUpQuestion{

	private static final String QUESTION_PROMPT = "Provide the length of your desired list:";
	private static final int LOWER_BOUND = 1;
	private static final String ERROR_MESSAGE = "Invalid input. Input must be a postive number.";

	/* Asks the user a follow up question
	 * If user gives an appropriate input, it will call a method to answer the question
	 * If not, it will ask the question again to the user and give a bad input message
	 */
	@Override
	public void askQuestion(Scanner userInput, HashMap<String,HashMap<String,String>> movies) {
		TopDirectors topDirector = new TopDirectors();
		askFollowUp(userInput, movies, QUESTION_PROMPT, ERROR_MESSAGE);
		topDirector.getTopDirectors(input, movies);
	}

	// I used code from this link https://stackoverflow.com/questions/35604342/im-trying-to-add-a-try-catch-that-tells-the-user-they-cant-plug-in-negative-numb
		// Used to throw an exception if the number is less than 1900 or greater than 2022
		//	if (input < 0) {
		//	     // this gets caught in the catch block
		//	     throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!"); 
		//	}      
		//	...
		//	} catch (IllegarArgumentException e) {
		//	    System.out.println(e.getMessage());
		//	}
	
	// Tests if the user gave a valid input
	@Override
	public void testInput(String userChoice) {
		int testNumber = Integer.parseInt(userChoice);
		
		if (testNumber < LOWER_BOUND) {
			throw new IllegalArgumentException(); 
		}
	}
	
}
