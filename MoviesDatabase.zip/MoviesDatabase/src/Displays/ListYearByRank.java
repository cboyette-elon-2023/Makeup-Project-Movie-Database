package Displays;
import java.util.HashMap;
import java.util.Scanner;

import Question.ListByYear;

public class ListYearByRank extends FollowUpQuestion{
	
	private static final String QUESTION_PROMPT = "2.  Highest Rated";
	private static final String ERROR_MESSAGE = "Invalid input. Input must be a postive number.";
	private static final String GROSS_INFO = "gross";
	private static final String TOP_RATED_INFO = "topRated";
	private HashMap<String,Runnable> rank;
	private HashMap<String,HashMap<String,String>> movie;
	
	// Sets up a data structure to answer the question based on the user inputs
	public ListYearByRank() {
		ListByYear listByYear = new ListByYear();
		rank = new HashMap<String,Runnable>();
		rank.put("1", () -> listByYear.listByYear(movie, GROSS_INFO));
		rank.put("2", () -> listByYear.listByYear(movie, TOP_RATED_INFO));
	}
	
	/* Asks the user a follow up question
	 * If user gives an appropriate input, it will call a method to answer the question
	 * If not, it will ask the question again to the user and give a bad input message
	 */
	@Override
	public void askQuestion(Scanner userInput, HashMap<String,HashMap<String,String>> movies) {
		askFollowUp(userInput, movies, QUESTION_PROMPT, ERROR_MESSAGE);
	}
	
	// Asks the user a follow up question and catches any bad inputs
	@Override
	protected void askFollowUp(Scanner userInput, HashMap<String,HashMap<String,String>> movies, String questionPrompt, String errorMessage) {
		System.out.println("Choose an option: ");
		System.out.println("1.  Highest Grossing");
		System.out.println(questionPrompt);
		movie = movies;
		input = userInput.nextLine();
		try {
			testInput(input);
		} catch (NullPointerException e) {
			System.out.println(errorMessage);
			askFollowUp(userInput, movies, questionPrompt, errorMessage);
		}
	}
	
	// Method to test if user has given a valid input
	@Override
	public void testInput(String userChoice) {
		rank.get(userChoice).run();	
	}
}
