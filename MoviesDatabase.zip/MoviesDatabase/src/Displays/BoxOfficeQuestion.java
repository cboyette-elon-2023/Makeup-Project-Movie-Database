package Displays;
import java.util.HashMap;
import java.util.Scanner;

import Question.TotalBoxOffice;

public class BoxOfficeQuestion extends FollowUpQuestion{

	private static final String QUESTION_PROMPT = "Provide a year:";
	private static final int LOWER_BOUND = 1900;
	private static final String ERROR_MESSAGE = "Invalid input. Please provide a year after the 20th century.";
	
	/* Asks the user a follow up question
	 * If user gives an appropriate input, it will call a method to answer the question
	 * If not, it will ask the question again to the user and give a bad input message
	 */
	@Override
	public void askQuestion(Scanner userInput, HashMap<String,HashMap<String,String>> movies) {
		TotalBoxOffice totalBoxOffice = new TotalBoxOffice();
		askFollowUp(userInput, movies, QUESTION_PROMPT, ERROR_MESSAGE);
		totalBoxOffice.getTopBoxOffice(input, movies);
	}

	// I used code from this link https://stackoverflow.com/questions/35604342/im-trying-to-add-a-try-catch-that-tells-the-user-they-cant-plug-in-negative-numb
		// Used to throw an exception if the number is less than 1900 or greater than 2022
		//	if (input < 0) {
		//	     // this gets caught in the catch block
		//	     throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!"); 
		//	}      
		//	...
		//	} catch (IllegarArgumentException e) {
		//	    System.out.println(e.getMessage());
		//	}
	
	// Tests if the user input is a valid answer
	@Override
	public void testInput(String userChoice) {
		int testNumber = Integer.parseInt(userChoice);
		
		if (testNumber < LOWER_BOUND) {
			throw new IllegalArgumentException(); 
		}
	}
	
}
