package Displays;
import java.util.HashMap;
import java.util.Scanner;

import Question.StarredOrDirected;

public class StarredOrDirectedQuestion extends FollowUpQuestion{
	
	private static final String QUESTION_PROMPT = "Please enter the rank you would like to see";
	private static final String ERROR_MESSAGE = "Invalid inputs";
	private static final int DIRECTOR_CATEGORY = 1;
	private static final int STARS_CATEGORY = 2;
	private static final String GROSS_INFO = "gross";
	private static final String TOP_RATED_INFO = "topRated";
	private static final String DIRECTOR_PRINT_MESSAGE = ", Director: ";
	private static final String STARS_PRINT_MESSAGE = ", Leading Cast: ";
	
	private HashMap<String,HashMap<String,Runnable>> directorStar;
	private HashMap<String,HashMap<String,String>> movie;
	private String numberRank;
	private String firstChoice;
	private String secondChoice;
	
	// Sets up a data structure to answer the question based on the user inputs
	public StarredOrDirectedQuestion() {
		StarredOrDirected starDirect = new StarredOrDirected();
		directorStar = new HashMap<String,HashMap<String,Runnable>>();
		HashMap<String,Runnable> grossRank = new HashMap<String,Runnable>();
		HashMap<String,Runnable> ratingRank = new HashMap<String,Runnable>();
		grossRank.put("1", () -> starDirect.getAnswer(numberRank, movie, GROSS_INFO, DIRECTOR_CATEGORY, DIRECTOR_PRINT_MESSAGE));
		grossRank.put("2", () -> starDirect.getAnswer(numberRank, movie, TOP_RATED_INFO, DIRECTOR_CATEGORY, DIRECTOR_PRINT_MESSAGE));
		ratingRank.put("1", () -> starDirect.getAnswer(numberRank, movie, GROSS_INFO, STARS_CATEGORY, STARS_PRINT_MESSAGE));
		ratingRank.put("2", () -> starDirect.getAnswer(numberRank, movie, TOP_RATED_INFO, STARS_CATEGORY, STARS_PRINT_MESSAGE));
		directorStar.put("1", grossRank);
		directorStar.put("2", ratingRank);
	}
	
	/* Asks the user a follow up question
	 * If user gives an appropriate input, it will call a method to answer the question
	 * If not, it will ask the question again to the user and give a bad input message
	 */
	@Override
	public void askQuestion(Scanner userInput, HashMap<String,HashMap<String,String>> movies) {
		movie = movies;
		System.out.println("Choose an option: ");
		System.out.println("1. Director");
		System.out.println("2. Stars");
		firstChoice = choiceFollowUp(userInput, movies);
		System.out.println("Choose an option: ");
		System.out.println("1.  Highest Grossing");
		System.out.println("2.  Highest Rated");
		secondChoice = choiceFollowUp(userInput, movies);
		askFollowUp(userInput, movies, QUESTION_PROMPT, ERROR_MESSAGE);
	}
	
	// Asks the user a follow up question where they have to choose certain options
	protected String choiceFollowUp(Scanner userInput, HashMap<String,HashMap<String,String>> movies) {
		String input = userInput.nextLine();
//		try {
			//testInputYieldsNullAnswer(input);
//		} catch (NullPointerException e) {
//			System.out.println(errorMessage);
//			choiceFollowUp(userInput, movies, errorMessage);
//		}
		return input;
	}
	
	// Asks the user a follow up question and catches any bad inputs
	@Override
	protected void askFollowUp(Scanner userInput, HashMap<String,HashMap<String,String>> movies, String questionPrompt, String errorMessage) {
		System.out.println(questionPrompt);
		numberRank = userInput.nextLine();
		try {
			testInputYieldsNullAnswer(firstChoice);
			testInputYieldsNullAnswer(secondChoice);
			testInput(numberRank);
		}
		
		catch (IllegalArgumentException|NullPointerException e) {
			System.out.println(errorMessage);
			askQuestion(userInput,movies);
		}
		directorStar.get(firstChoice).get(secondChoice).run();
	}
	
	// Tests if the user chose one of the options
	public void testInputYieldsNullAnswer(String input) {
		if (directorStar.get(input) == null) {
			throw new NullPointerException();
		}
	}
	
	// I used code from this link https://stackoverflow.com/questions/35604342/im-trying-to-add-a-try-catch-that-tells-the-user-they-cant-plug-in-negative-numb
	// Used to throw an exception if the number is negative
	//	if (input < 0) {
	//	     // this gets caught in the catch block
	//	     throw new IllegalArgumentException("Only Positive Numbers & no Letters Please!"); 
	//	}      
	//	...
	//	} catch (IllegarArgumentException e) {
	//	    System.out.println(e.getMessage());
	//	}
	
	// Tests if the user gave a valid input
	@Override
	public void testInput(String input) {
		int testNumber = Integer.parseInt(numberRank);
		if (testNumber <= 0 || testNumber > 250) {
			throw new IllegalArgumentException(); 
		}
	}
}
