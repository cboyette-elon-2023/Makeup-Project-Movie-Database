package Displays;
import java.util.HashMap;
import java.util.Scanner;

import File.Cast;
import File.Gross;
import File.TopRated;
import Question.Directors;

public class Display {
	
	private Scanner userInput;
	private HashMap<String,Runnable> followUpQuestion;
	private HashMap<String,HashMap<String,String>> movies;
	private Directors director;
	private TopDirectorsQuestion topDirector;
	private BoxOfficeQuestion boxOffice;
	private Gross gross;
	private TopRated topRated;
	private Cast cast;
	private StarredOrDirectedQuestion starredDirected;
	private ListYearByRank listYearByRank;
	
	private static final String GROSS_FILE = "/imdb_movies_gross.txt";
	private static final String CAST_FILE = "/imdb_movies_cast.txt";
	private static final String TOP_RATED_FILE = "/imdb_movies_toprated.txt";
	private static final String FULL_DATA_FOLDER = "MovieFiles";
	
	//Sets up the maps and other instance variables that will be needed
	public Display() {
		userInput = new Scanner(System.in);
		intializeVariables();
		setUpInitialQuestions();
	}
	
	/*Stores the data 
	 * Displays the initial questions for the user
	 * Takes the user input and checks if it is a valid answer
	 * If there is a follow up question, it will ask the user it
	 * If not, the program will answer the question and display the answer to the user
	 */ 
	public void initialQuestions() {
		movies = readStoreData(FULL_DATA_FOLDER);
		intialQuestionsDisplay();
		String selection = userInput.nextLine();
		try {
			processUserSelection(selection);
			userInput.close();
		} catch (NullPointerException e) {
			System.out.println("Invalid selection choice. Please pick one of the options presented on the screen.");
			initialQuestions();
		}
	}
	
	// Attempts to take the user input and perform an action
	public void processUserSelection(String selection) {
		followUpQuestion.get(selection).run();
		userInput.close();
	}
	
	// Terminates the application and displays a goodbye message 
	protected void quitApplication() {
		System.out.println("Goodbye!");
		userInput.close();
		System.exit(0);
	}
	
	// Stores the data from the three different data files
	public HashMap<String,HashMap<String,String>> readStoreData(String folderName){
		movies = gross.readThroughAllData(folderName + GROSS_FILE, movies);
		movies = topRated.readThroughAllData(folderName + TOP_RATED_FILE, movies);
		movies = cast.readThroughAllData(folderName + CAST_FILE, movies);
		return movies;
	}
	
	// Sets up map for what should be done based on initial user input
	// I used code from the following link https://stackoverflow.com/questions/45410573/java-runnable-hashmap-with-args
	// It was used to help execute methods using a HashMap
	//HashMap<String, Runnable> cmdList = new HashMap<>();
	//cmdList.put("teleport", () -> myVoidWithArgs(arg1, arg2));
	//cmdList.put("kill", () -> myOtherVoidWithArgs(arg1, arg2));
	//cmdList.get("teleport").run("Player", "coords");
	//cmdList.get("kill").run("Player", "Message");
	private void setUpInitialQuestions() {
		followUpQuestion.put("A", () -> boxOffice.askQuestion(userInput, movies));
		followUpQuestion.put("B", () -> director.getListOfDirectors(movies));
		followUpQuestion.put("C", () -> topDirector.askQuestion(userInput, movies)); 
		followUpQuestion.put("D", () -> starredDirected.askQuestion(userInput, movies)); 
		followUpQuestion.put("E", () -> listYearByRank.askQuestion(userInput, movies)); 
		followUpQuestion.put("Q", () -> quitApplication());
	}
	
	// Initializes instance variables and other important data structures
	private void intializeVariables() {
		followUpQuestion = new HashMap<String,Runnable>();
		director = new Directors();
		topDirector = new TopDirectorsQuestion();
		boxOffice = new BoxOfficeQuestion();
		gross = new Gross();
		topRated = new TopRated();
		cast = new Cast();
		movies = new HashMap<String,HashMap<String,String>>();
		starredDirected = new StarredOrDirectedQuestion();
		listYearByRank = new ListYearByRank();
	}
	
	private void intialQuestionsDisplay() {
		System.out.println("Choose an option. Letters must be captialized when typed in: ");
		System.out.println("A.  Show total box office earnings for a given year.");
		System.out.println("B.  Show a list of all people who have directed a movie.");
		System.out.println("C.  Show the most popular directors.");
		System.out.println("D.  Show the stars or directors of a movie based on the movie's rank.");
		System.out.println("E.  Show the number of films for each year based on rank.");
		System.out.println("Q.  Quit");
	}
}
