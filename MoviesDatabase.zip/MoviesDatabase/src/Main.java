import Displays.Display;

public class Main {
	
	//Use this class to test out user I/O and the full data
	
	public static void main(String[] args) {
		Display display = new Display();
		display.initialQuestions();
	}
	
}
