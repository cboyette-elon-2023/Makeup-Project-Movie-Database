package File;

import java.util.HashMap;
import java.util.Scanner;

public class Cast extends Files{

	private static final String TYPE_OF_FILE = "cast";
	
	private HashMap<String,String> movieCast = new HashMap<String,String>();

	// Stores the data in appropriate data structures
	@Override
	protected void storeData(Scanner lineScanner, String typeOfFile, HashMap<String,String> movieCast) {
		String key = "";
		String titleYear = "";
		key += lineScanner.next();
		key += "\t";
		titleYear += lineScanner.next();
		titleYear += "\t";
		titleYear += lineScanner.next();
		key += lineScanner.next();
		key += "\t";
		key += lineScanner.next();
		key += ", ";
		key += lineScanner.next();
		key += ", ";
		key += lineScanner.next();
		key += ", ";
		key += lineScanner.next();
		key += ", ";
		key += lineScanner.next();
		movieCast.put(titleYear, key);
		movie.put(typeOfFile, movieCast);
	}
	
	// Parses the data and gets it ready to be stored
	@Override
	protected void parseData(String dataLine) {
		Scanner lineScanner = new Scanner(dataLine);
		//Tells the scanner that the data is separated by commas
		lineScanner.useDelimiter("\t");
		while(lineScanner.hasNext()) {
			storeData(lineScanner, TYPE_OF_FILE, movieCast);
		}		
	}
}
