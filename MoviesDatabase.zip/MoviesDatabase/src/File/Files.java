package File;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public abstract class Files {
	
	protected HashMap<String,HashMap<String,String>> movie;
	
	/* Takes the provided file and checks if it is a valid filename
	 * If it is, calls another method to parse the data
	 * If not, an error message is provided
	 */ 
	public HashMap<String,HashMap<String,String>> readThroughAllData(String filename, HashMap<String,HashMap<String,String>> movies) {
		try {
			Scanner scanner = new Scanner(new File(filename));
			scanner.nextLine();
			movie = movies;
			while(scanner.hasNextLine()){
				String dataLine = scanner.nextLine();
				parseData(dataLine);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Invalid file. Please provide a valid data file");
		}
		return movies;
	}
	
	// Parses the data and gets it ready to be stored
	protected abstract void parseData(String dataLine);
	
	// Stores the data in appropriate data structures
	protected void storeData(Scanner lineScanner, String typeOfFile, HashMap<String,String> dataStorage) {
		String key = "";
		String titleYear = "";
		key += lineScanner.next();
		key += "\t";
		titleYear += lineScanner.next();
		titleYear += "\t";
		titleYear += lineScanner.next();
		key += lineScanner.next();
		dataStorage.put(titleYear, key);
		movie.put(typeOfFile, dataStorage);
	}
	
}
