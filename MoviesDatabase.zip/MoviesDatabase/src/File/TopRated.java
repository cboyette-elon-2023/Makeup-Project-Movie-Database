package File;

import java.util.HashMap;
import java.util.Scanner;

public class TopRated extends Files{
	
	private static final String TYPE_OF_FILE = "topRated";
	
	private HashMap<String,String> movieTopRated = new HashMap<String,String>();
	
	// Parses the data and gets it ready to be stored
	@Override
	protected void parseData(String dataLine) {
		Scanner lineScanner = new Scanner(dataLine);
		//Tells the scanner that the data is separated by commas
		lineScanner.useDelimiter("\t");
		while(lineScanner.hasNext()) {
			storeData(lineScanner, TYPE_OF_FILE, movieTopRated);
		}		
	}
	
}
