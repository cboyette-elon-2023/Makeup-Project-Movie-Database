package Question;

import java.util.ArrayList;
import java.util.HashMap;

public class TotalBoxOffice{
	
	private static final int YEAR_CATEGORY = 1;
	private static final int BOX_OFFICE_CATEGORY = 1;
	
	/* Calls a method to find the movies that were made in the user provided year 
	 * Then, a method is called to find the amount of money the movie made at the box office
	 * Next, a method is called to loop through the list of movies and finds the total amount earned at the box office during the user provided year
	 * Afterward, it displays the information to the user
	 * Lastly, the program is terminated
	 */
	public void getTopBoxOffice(String year, HashMap<String,HashMap<String,String>> movies) {
		HashMap<String, String> gross = movies.get("gross");
		ArrayList<String> keys = breakUpKey(gross, year);
		long boxOffice = getTotalBoxOffice(gross, keys);
		System.out.println("The total box office revenue for " + year + " was $" + boxOffice);
		System.exit(0);
	}
	
	// Finds the movies that were made in the user provided year
	public ArrayList<String> breakUpKey(HashMap<String, String> gross, String year) {
		ArrayList<String> correctYearKeys = new ArrayList<String>();
		for (String key: gross.keySet()) {
			String[] keys = key.split("\t");
			if (keys[YEAR_CATEGORY].equals(year)) {
				correctYearKeys.add(key);
			}
		}
		return correctYearKeys;
	}
	
	// Finds the amount of money the movie made at the box office
	private int breakUpValue(String value) {
		String[] values = value.split("\t");
		int boxOffice = Integer.parseInt(values[BOX_OFFICE_CATEGORY]);
		return boxOffice;
	}
	
	// Loops through the list of movies and finds the total amount earned at the box office during the user provided year
	public long getTotalBoxOffice(HashMap<String, String> gross, ArrayList<String> keys) {
		long totalBoxOffice = 0;
		for (int i = 0; i < keys.size(); i++) {
			String value = gross.get(keys.get(i));
			int boxOffice = breakUpValue(value);
			totalBoxOffice += boxOffice;
		}
		return totalBoxOffice;
	}
	
}
