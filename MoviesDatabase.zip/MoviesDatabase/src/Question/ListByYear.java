package Question;

import java.util.HashMap;
import java.util.TreeMap;

public class ListByYear {
	
	private static final int YEAR_CATEGORY = 1;
	
	/* Calls a method to find the number of movies for each year in the database in an ordered list
	 * Loops through the list and displays the information to the user
	 * Afterward, terminates the program
	 */
	public void listByYear(HashMap<String,HashMap<String,String>> movies, String typeOfCatrgory) {
		HashMap<String, String> rankCatgory = movies.get(typeOfCatrgory);
		TreeMap<String, Integer> years = getNumberOfMoviesForEachYear(rankCatgory);
		for (String key: years.keySet()) {
			System.out.println("Year: " + key + ", Number of Movies: " + years.get(key));
		}
		System.exit(0);
	}
	
	// Stores the number of movies for each year in the database in an ordered list
	public TreeMap<String,Integer> getNumberOfMoviesForEachYear(HashMap<String,String> movies) {
		TreeMap<String, Integer> numberOfMoviesPerYear = new TreeMap<String, Integer>();
		for (String key: movies.keySet()) {
			String[] keys = key.split("\t");
			String year = keys[YEAR_CATEGORY];
			if (numberOfMoviesPerYear.containsKey(year)) {
				numberOfMoviesPerYear.replace(year, numberOfMoviesPerYear.get(year) + 1);
			}
			else {
				numberOfMoviesPerYear.put(year, 1);
			}
		}
		return numberOfMoviesPerYear;
	}
	
}
