package Question;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.List;
import java.util.stream.Collectors;

public class TopDirectors{
	
	private static final int DIRECTOR_CATEGORY = 1;
	
	/* Calls a method to store the names of all the directors
	 * Then, calls a method to store the number of movies each director has done
	 * Next, it swaps the keys and values for the director frequency map and stores them in a tree Map so they can be sorted
	 * Afterward, a method is called to create a list of the top working directors based on the user provided length
	 * Then, it loops through the list and displays the information to the user
	 * Lastly, the program is terminated
	 */
	public void getTopDirectors(String lengthList, HashMap<String,HashMap<String,String>> movies) {
		HashMap<String, String> cast = movies.get("cast");
		ArrayList<String> directorNames = getDirectorsNames(cast);
		HashMap<Object, Integer> directors = getDirectorFrequency(directorNames);
		TreeMap<Object, List<Object>> directorFrequency = new TreeMap<Object, List<Object>>();
		Map<Object, List<Object>> swappedKeysValues = directors.entrySet().stream().collect(Collectors.groupingBy(Map.Entry::getValue, Collectors.mapping(Map.Entry::getKey, Collectors.toList()))); 
		directorFrequency.putAll(swappedKeysValues);
		ArrayList<Object> directorsInOrderOfMoviesMade = topDirectors(directorFrequency, lengthList);
		for (int i = 0; i < directorsInOrderOfMoviesMade.size(); i++) {
			System.out.println("Director: " + directorsInOrderOfMoviesMade.get(i) + ", Number of Movies: " + directors.get(directorsInOrderOfMoviesMade.get(i)));
		}
		System.exit(0);
	}
	
	// Stores the names of all the directors
	public ArrayList<String> getDirectorsNames(HashMap<String, String> cast) {
		ArrayList<String> directorNames = new ArrayList<String>();
		for (String key: cast.keySet()) {
			String value = cast.get(key);
			String[] values = value.split("\t");
			directorNames.add(values[DIRECTOR_CATEGORY]);
		}
		return directorNames;
	}
	
	// stores the number of movies each director has done
	public HashMap<Object, Integer> getDirectorFrequency(ArrayList<String> directorNames) {
		HashMap<Object, Integer> directors = new HashMap<Object, Integer>();
		for (int i = 0; i < directorNames.size(); i++) {
			if (directors.containsKey(directorNames.get(i))) {
				directors.replace(directorNames.get(i), directors.get(directorNames.get(i)) + 1);
			}
			else {
				directors.put(directorNames.get(i), 1);
			}
		}
		return directors;
	}
	
	// Creates a list of the top working directors based on the user provided length
	public ArrayList<Object> topDirectors(TreeMap<Object, List<Object>> directorFrequency, String lengthList) {
		ArrayList<Object> directorsNames = new ArrayList<Object>();
		int count = 0;
		for (Object key: directorFrequency.descendingKeySet()) {
			for (int i = 0; i < directorFrequency.get(key).size(); i++) {
				if (count == Integer.parseInt(lengthList)) {
					break;
				}
				else {
					directorsNames.add(directorFrequency.get(key).get(i));
					count++;
				}
			}
		}
		return directorsNames;
	}
	
}
