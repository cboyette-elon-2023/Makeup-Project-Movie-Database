package Question;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StarredOrDirected {
	
	private static final int RANK_CATEGORY = 0;
	private static final int KEY_VALUE_ORDER = 1;
	private static final int VALUE_KEY_ORDER = 2;
	
	/* Calls a method to store movie and rank or movie and director or cast
	 * Based on the user provided rank and whether they wanted cast or director, it will find the corresponding movie and display all the information
	 * Afterward, the program will terminate
	 */
	public void getAnswer(String rank, HashMap<String,HashMap<String,String>> movies, String typeOfRank, int valueOfInterest, String printMessage) {
		HashMap<String, String> cast = movies.get("cast");
		HashMap<String, String> rankInfo = movies.get(typeOfRank);
		HashMap<String, String> movieRanks = breakUpMap(rankInfo, RANK_CATEGORY, VALUE_KEY_ORDER);
		HashMap<String, String> movieDirectOrStar = breakUpMap(cast, valueOfInterest, KEY_VALUE_ORDER);
		String movieName = movieRanks.get(rank);
		String directOrStar = movieDirectOrStar.get(movieName);
		System.out.println("Rank: " + rank + ", Movie: " + movieName + printMessage + directOrStar);
		System.exit(0);
	}
	
	// Based on whether movie needs to be the key or the value, it stores movie and rank or movie and director or cast
	public HashMap<String,String> breakUpMap(HashMap<String,String> movies, int category, int order) {
		HashMap<String,String> movieRanks = new HashMap<String,String>();
		for (String key: movies.keySet()) {
			String[] keys = key.split("\t");
			String movieName = keys[0];
			String value = movies.get(key);
			String[] values = value.split("\t");
			String rank = values[category];
			if (order == VALUE_KEY_ORDER) {
				movieRanks.put(rank, movieName);
			}
			else {
				movieRanks.put(movieName, rank);
			}
		}
		return movieRanks;
	}
}