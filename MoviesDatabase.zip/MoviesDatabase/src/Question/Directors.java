package Question;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Directors{
	
	private static final int MOVIE_CATEGORY = 0;
	private static final int DIRECTOR_CATEGORY = 1;
	
	private HashMap<String, String> directors;
	
	// Initializes an instance variable the directors as keys and a movie they've directed as a value
	public Directors() {
		directors = new HashMap<String, String>();
	}
	
	/* Calls a method to create an alphabetical list of the directors and store the director and a movie they have directed
	 * Loops through the alphabetical list and displays the information to the user
	 * Afterward, terminates the program
	 */
	public void getListOfDirectors(HashMap<String,HashMap<String,String>> movies) {
		HashMap<String, String> cast = movies.get("cast");
		ArrayList<String> alphabeticalDirectors = createAlphabticalListOfDirectors(cast);
		for (int i = 0; i < alphabeticalDirectors.size(); i++) {
			System.out.println("Director: " + alphabeticalDirectors.get(i) + ", Movie: " + directors.get(alphabeticalDirectors.get(i)));
		}
		System.exit(0);
	}
	
	/* Creates an alphabetical list of the directors
	 * Stores the directors and one movie they have directed
	 */
	
	public ArrayList<String> createAlphabticalListOfDirectors(HashMap<String, String> cast) {
		ArrayList<String> alphabetizedList = new ArrayList<String>();
		for (String key: cast.keySet()) {
			String value = cast.get(key);
			String[] values = value.split("\t");
			if (!(directors.keySet()).contains(values[DIRECTOR_CATEGORY])) {
				String[] keys = key.split("\t");
				directors.put(values[DIRECTOR_CATEGORY], keys[MOVIE_CATEGORY]);
				alphabetizedList.add(values[DIRECTOR_CATEGORY]);
			}
		}
		
		Collections.sort(alphabetizedList);
		return alphabetizedList;
	}
}
