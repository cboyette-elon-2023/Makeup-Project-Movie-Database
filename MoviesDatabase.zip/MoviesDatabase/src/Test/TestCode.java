package Test;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.io.FileNotFoundException;

import org.junit.Test;

import Displays.BoxOfficeQuestion;
import Displays.Display;
import Displays.ListYearByRank;
import Displays.StarredOrDirectedQuestion;
import Displays.TopDirectorsQuestion;
import Question.Directors;
import Question.ListByYear;
import Question.StarredOrDirected;
import Question.TopDirectors;
import Question.TotalBoxOffice;

public class TestCode {
	//Use this class to see the program run on a test set of data
	
	private static final String TEST_DATA_FOLDER = "TestMovieFiles";
	private static final String GROSS_DATA = "gross";
	private static final String TOP_RATED_DATA = "topRated";
	private static final String CAST_DATA = "cast";
	private static final int DIRECTOR_CATEGORY = 1;
	private static final int STARS_CATEGORY = 2;
	private static final int RANK_CATEGORY = 0;
	private static final int KEY_VALUE_ORDER = 1;
	private static final int VALUE_KEY_ORDER = 2;
	
	// I used code from this link https://www.baeldung.com/junit-assert-exception
	// Used to test for an exception
//	@Test(expected = NullPointerException.class)
//	public void whenExceptionThrown_thenExpectationSatisfied() {
//	    String test = null;
//	    test.length();
//	}
	
	// Tests whether there is no data stored for a bad folder input
	@Test
	public void TestIncorrectFilename() {
		String invalidFolderName = "abc";
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(invalidFolderName); 
		HashMap<String,HashMap<String,String>> expectedOutput = new HashMap<String,HashMap<String,String>>();
		assertEquals(movies, expectedOutput);
	}
	
	// Tests whether an exception is thrown if a user gives a bad initial input
	@Test(expected = NullPointerException.class)
	public void TestIncorrectInitialQuestionInput() {
		Display display = new Display();
		String selection = "Z";
		display.processUserSelection(selection);
	}
	
	// Tests whether the total box office for a given year is calculated correctly
	@Test
	public void TestCorrectTotalBoxOffice() {
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		TotalBoxOffice totalBoxOffice = new TotalBoxOffice();
		String year = "1981";
		HashMap<String, String> gross = movies.get(GROSS_DATA);
		ArrayList<String> keys = totalBoxOffice.breakUpKey(gross, year);
		long boxOffice = totalBoxOffice.getTotalBoxOffice(gross, keys);
		long expectedBoxOffice = 889447195;
		assertEquals(boxOffice, expectedBoxOffice);
	}
	
	// Tests whether an exception is thrown if a user gives a too low input for the box office question
	@Test(expected = IllegalArgumentException.class)
	public void TestTooLowYear() {
		BoxOfficeQuestion boxOffice = new BoxOfficeQuestion();
		String input = "1899";
		boxOffice.testInput(input);
	}
	
	// Tests whether an exception is thrown if a user gives a input that is not a number for the box office question
	@Test(expected = IllegalArgumentException.class)
	public void TestYearInputNotANumber() {
		BoxOfficeQuestion boxOffice = new BoxOfficeQuestion();
		String input = "abc";
		boxOffice.testInput(input);
	}
	
	// Tests whether the ordered, no duplicate directors list is created correctly
	@Test
	public void TestCorrectListOfDirectors() {
		ArrayList<String> expectedDirectors = new ArrayList<String>();
		expectedDirectors.add("Christopher Nolan");
		expectedDirectors.add("Frank Darabont");
		expectedDirectors.add("Irvin Kershner");
		expectedDirectors.add("Peter Jackson");
		expectedDirectors.add("Richard Marquand");
		expectedDirectors.add("Robert Zemeckis");
		expectedDirectors.add("Steven Spielberg");
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		HashMap<String, String> cast = movies.get(CAST_DATA);
		Directors director = new Directors();
		ArrayList<String> alphabeticalDirectors = director.createAlphabticalListOfDirectors(cast);
		assertEquals(alphabeticalDirectors, expectedDirectors);
	}
	
	// Tests whether the most prevalent directors list for a given user list length is correct 
	@Test
	public void TestCorrectMostPopularDirectors() {
		ArrayList<Object> expectedDirectorNames = new ArrayList<Object>();
		expectedDirectorNames.add("Peter Jackson");
		expectedDirectorNames.add("Frank Darabont");
		expectedDirectorNames.add("Christopher Nolan");
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER);
		TopDirectors topDirector = new TopDirectors();
		HashMap<String, String> cast = movies.get(CAST_DATA);
		ArrayList<String> directorNames = topDirector.getDirectorsNames(cast);
		HashMap<Object, Integer> directors = topDirector.getDirectorFrequency(directorNames);
		TreeMap<Object, List<Object>> directorFrequency = new TreeMap<Object, List<Object>>();
		Map<Object, List<Object>> swappedKeysValues = directors.entrySet().stream().collect(Collectors.groupingBy(Map.Entry::getValue, Collectors.mapping(Map.Entry::getKey, Collectors.toList()))); 
		directorFrequency.putAll(swappedKeysValues);
		String lengthList = "3";
		ArrayList<Object> directorsInOrderOfMoviesMade = topDirector.topDirectors(directorFrequency, lengthList);
		assertEquals(directorsInOrderOfMoviesMade, expectedDirectorNames);
	}
	
	// Tests whether an exception is thrown if a user gives a input that is not a number for the popular directors question
	@Test(expected = IllegalArgumentException.class)
	public void TestNotANumberInputLengthOfPopularDirectorsList() {
		TopDirectorsQuestion topDirector = new TopDirectorsQuestion();
		String input = "abc";
		topDirector.testInput(input);
	}
	
	// Tests whether an exception is thrown if a user gives a too low input for the popular directors question
	@Test(expected = IllegalArgumentException.class)
	public void TestTooLowNumberInputLengthOfPopularDirectorsList() {
		TopDirectorsQuestion topDirector = new TopDirectorsQuestion();
		String input = "-2";
		topDirector.testInput(input);
	}
	
	// Tests whether the user provided ranked movie on the gross list provides the correct director
	@Test
	public void TestCorrectDirectorBasedOnGrossRank() {
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		StarredOrDirected starDirect = new StarredOrDirected();
		HashMap<String, String> cast = movies.get(CAST_DATA);
		HashMap<String, String> gross = movies.get(GROSS_DATA);
		HashMap<String, String> movieRanks = starDirect.breakUpMap(gross, RANK_CATEGORY, VALUE_KEY_ORDER);
		HashMap<String, String> movieDirectOrStar = starDirect.breakUpMap(cast, DIRECTOR_CATEGORY, KEY_VALUE_ORDER);
		String rank = "4";
		String movieName = movieRanks.get(rank);
		String director = movieDirectOrStar.get(movieName);
		String expectedDirector = "Peter Jackson";
		assertEquals(director, expectedDirector);
	}
	
	// Tests whether the user provided ranked movie on the ranked list provides the correct director
	@Test
	public void TestCorrectDirectorBasedOnRatingRank() {
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		StarredOrDirected starDirect = new StarredOrDirected();
		HashMap<String, String> cast = movies.get(CAST_DATA);
		HashMap<String, String> topRated = movies.get(TOP_RATED_DATA);
		HashMap<String, String> movieRanks = starDirect.breakUpMap(topRated, RANK_CATEGORY, VALUE_KEY_ORDER);
		HashMap<String, String> movieDirectOrStar = starDirect.breakUpMap(cast, DIRECTOR_CATEGORY, KEY_VALUE_ORDER);
		String rank = "4";
		String movieName = movieRanks.get(rank);
		String director = movieDirectOrStar.get(movieName);
		String expectedDirector = "Robert Zemeckis";
		assertEquals(director, expectedDirector);
	}

	// Tests whether the user provided ranked movie on the gross list provides the correct cast
	@Test
	public void TestCorrectStarsBasedOnGrossRank() {
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		StarredOrDirected starDirect = new StarredOrDirected();
		HashMap<String, String> cast = movies.get(CAST_DATA);
		HashMap<String, String> gross = movies.get(GROSS_DATA);
		HashMap<String, String> movieRanks = starDirect.breakUpMap(gross, RANK_CATEGORY, VALUE_KEY_ORDER);
		HashMap<String, String> movieDirectOrStar = starDirect.breakUpMap(cast, STARS_CATEGORY, KEY_VALUE_ORDER);
		String rank = "4";
		String movieName = movieRanks.get(rank);
		String stars = movieDirectOrStar.get(movieName);
		String expectedStars = "Alan Howard, Elijah Wood, Noel Appleby, Sean Astin, Sala Baker";
		assertEquals(stars, expectedStars);
	}
	
	// Tests whether the user provided ranked movie on the rating list provides the correct cast
	@Test
	public void TestCorrectStarsBasedOnRatingRank() {
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		StarredOrDirected starDirect = new StarredOrDirected();
		HashMap<String, String> cast = movies.get(CAST_DATA);
		HashMap<String, String> topRated = movies.get(TOP_RATED_DATA);
		HashMap<String, String> movieRanks = starDirect.breakUpMap(topRated, RANK_CATEGORY, VALUE_KEY_ORDER);
		HashMap<String, String> movieDirectOrStar = starDirect.breakUpMap(cast, STARS_CATEGORY, KEY_VALUE_ORDER);
		String rank = "4";
		String movieName = movieRanks.get(rank);
		String stars = movieDirectOrStar.get(movieName);
		String expectedStars = "Tom Hanks, Rebecca Williams, Sally Field, Michael Conner Humphreys, Harold G. Herthum";
		assertEquals(stars, expectedStars);
	}
	
	// Tests whether an exception is thrown if the user choices an invalid choice for the user provided ranked movie question
	@Test(expected = NullPointerException.class)
	public void TestIncorrectTypeOfPerson() {
		StarredOrDirectedQuestion starredDirected = new StarredOrDirectedQuestion();
		starredDirected.testInputYieldsNullAnswer("3");
	}
	
	// Tests whether an exception is thrown if the user provides a choice that is not a number for the user provided ranked movie question
	@Test(expected = NullPointerException.class)
	public void TestIncorrectTypeOfRankPeople() {
		StarredOrDirectedQuestion starredDirected = new StarredOrDirectedQuestion();
		starredDirected.testInputYieldsNullAnswer("abc");
	}
	
	// Tests whether an exception is thrown if the user provides a rank that is not a number for the user provided ranked movie question
	@Test(expected = IllegalArgumentException.class)
	public void TestNotANumberRankPeople() {
		StarredOrDirectedQuestion starredDirected = new StarredOrDirectedQuestion();
		starredDirected.testInput("abc");
	}
	
	// Tests whether an exception is thrown if the user provides a rank that is too low for the user provided ranked movie question
	@Test(expected = IllegalArgumentException.class)
	public void TestTooLowRankPeople() {
		StarredOrDirectedQuestion starredDirected = new StarredOrDirectedQuestion();
		starredDirected.testInput("0");
	}
	
	// Tests whether an exception is thrown if the user provides a rank that is too high for the user provided ranked movie question
	@Test(expected = IllegalArgumentException.class)
	public void TestTooHighRankPeople() {
		StarredOrDirectedQuestion starredDirected = new StarredOrDirectedQuestion();
		starredDirected.testInput("251");
	}
	
	// Tests whether the number of films for each year based on the gross list is correct
	@Test
	public void TestCorrectNumberOfFilmsForYearGross() {
		TreeMap<String, Integer> expectedMoviesPerYear = new TreeMap<String, Integer>();
		expectedMoviesPerYear.put("1939", 1);
		expectedMoviesPerYear.put("1980", 1);
		expectedMoviesPerYear.put("1981", 3);
		expectedMoviesPerYear.put("1983", 1);
		expectedMoviesPerYear.put("1994", 1);
		expectedMoviesPerYear.put("2001", 1);
		expectedMoviesPerYear.put("2002", 1);
		expectedMoviesPerYear.put("2005", 1);
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		HashMap<String, String> gross = movies.get(GROSS_DATA);
		ListByYear listByYear = new ListByYear();
		TreeMap<String, Integer> moviesPerYear = listByYear.getNumberOfMoviesForEachYear(gross);
		assertEquals(moviesPerYear, expectedMoviesPerYear);
	}
	
	// Tests whether the number of films for each year based on the rating list is correct
	@Test
	public void TestCorrectNumberOfFilmsForYearRank() {
		TreeMap<String, Integer> expectedMoviesPerYear = new TreeMap<String, Integer>();
		expectedMoviesPerYear.put("1939", 1);
		expectedMoviesPerYear.put("1973", 1);
		expectedMoviesPerYear.put("1980", 1);
		expectedMoviesPerYear.put("1981", 2);
		expectedMoviesPerYear.put("1983", 1);
		expectedMoviesPerYear.put("2001", 2);
		expectedMoviesPerYear.put("2007", 1);
		expectedMoviesPerYear.put("2009", 1);
		Display display = new Display();
		HashMap<String,HashMap<String,String>> movies = display.readStoreData(TEST_DATA_FOLDER); 
		HashMap<String, String> topRated = movies.get(TOP_RATED_DATA);
		ListByYear listByYear = new ListByYear();
		TreeMap<String, Integer> moviesPerYear = listByYear.getNumberOfMoviesForEachYear(topRated);
		assertEquals(moviesPerYear, expectedMoviesPerYear);
	}
	
	// Tests whether an exception is thrown if the user provides an incorrect choice
	@Test(expected = NullPointerException.class)
	public void TestIncorrectTypeOfRankNumberOfFilms() {
		ListYearByRank listYearByRank = new ListYearByRank();
		listYearByRank.testInput("abc");
	}
}
